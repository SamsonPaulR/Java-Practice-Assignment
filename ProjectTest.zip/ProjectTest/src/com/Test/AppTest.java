package com.Test;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import com.pack.MainClass;
import static org.junit.Assert.*;
public class AppTest {
	
	/*
    @BeforeAll
    static void beforeAllMethod() {
        System.out.println("Run Only Once - Before All");
    }

    @AfterAll
    static void afterAllMethod() {
        System.out.println("Run Only Once - After All");
    }

    @BeforeEach
    void beforeEachMethod() {
        System.out.println("Executed before each test method");
    }

    @AfterEach
    void afterEachMethod() {
        System.out.println("Executed after each test method");
    }

    @Test
    void testMethod1() {
        System.out.println("hello");
    }

    @Test
    void testMethod2() {
        System.out.println("hello Samson");
    } */
	
	
	static MainClass obj = null;
	
	@BeforeAll
	public static void before1()
	{
		obj=new MainClass();
	}

	
	@Test
	@DisplayName("Add 2 no")
	public void addMeth() {
		//MainClass obj = new MainClass();
		int act_output = obj.addMeth(4, 60);
		
		int expect_output = 11;
		
//		int expect_output = 64;
		
		assertEquals(act_output, expect_output);
	}
	
	
	@Test
	@DisplayName("check String")
	public void testcheckString() {
		//MainClass obj1 = new MainClass();
		boolean b = obj.checkString("Sam");
		assertTrue(b);
	}
	
	@ParameterizedTest
	@ValueSource(strings= {"ram","annu","banu"})
	public void testcheckString(String str)
	{
		
		boolean b=obj.checkString(str);
		assertTrue(b);
		
	}
	
	@RepeatedTest(3)
	public void theRepeat(){
		System.out.println();
	}
	
	@Test
	@DisplayName("testing the exception")
	public void testmeth() {
	    String s = " ";
	    Throwable exception = assertThrows(IllegalArgumentException.class, () -> {
	        obj.methodForException(s);
	    });
	}
	
	
	@Test
	@DisplayName("testing in environment")
	@Tag("div")
	public void meth() {
		System.out.println("testing method in testing phase");
	}
	
	

	    @Tag("include")
	    @Test
	    public void testToInclude() {
	        // This test will be included
	    	System.out.println("this is include");
	    }

	    @Tag("exclude")
	    @Test
	    public void testToExclude() {
	        // This test will be excluded
	    	System.out.println("this is exclude");
	    }
	

	
	
	@Disabled
	public void methUnderTesting() {
		System.out.println("hello");
	}
	
	
}
