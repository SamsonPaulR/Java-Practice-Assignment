package com.util;

import java.time.LocalDate;
import java.util.ArrayList;

import com.Service.ServiceDao;
import com.model.Student;

public class Main1 {

	public static void main(String[] args) {
		
		ArrayList<Student> students = new ArrayList();
		Student s1 = new Student(01,"Samson", LocalDate.parse("11-11-2011"));
		Student s2 = new Student(02,"Wilson", LocalDate.parse("12-12-2012"));
		Student s3 = new Student(03,"Richard", LocalDate.parse("13-13-2013"));
		
		ServiceDao.insertStudents(students);

	}

}
