package com.Service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

import com.Connection.DbConnection;
import com.model.Student;
import com.util.Main1;

public class ServiceDao {
	

	public static void insertStudents(ArrayList<Student> students) {
		
		Connection con=	DbConnection.getConnection();	
		for(Student s: students) {
			try {
				String sql="insert into Student values(?,?,?)";
				PreparedStatement ps=con.prepareStatement(sql);
				ps.setInt(1,s.getId());
				ps.setString(2,s.getName());
				 ps.setDate(3, Date.valueOf(s.getDob()));
				int d1=ps.executeUpdate();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	

}
