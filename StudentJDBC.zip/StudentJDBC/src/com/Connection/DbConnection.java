package com.Connection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnection {
	
	public static Connection getConnection() {
        Connection con = null;
        
        try {
        	Class.forName("org.postgresql.Driver");
        	con = DriverManager.getConnection("jdbc:postgresql://localhost/sundaram", "postgres", "samson2002");
        	System.out.println("Connection established successfully.");
    } catch (Exception e) {
        System.out.println("Connection failed: " + e.getMessage());
    }
    return con;
        
	}

}
