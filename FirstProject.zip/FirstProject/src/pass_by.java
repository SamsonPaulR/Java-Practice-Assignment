
public class pass_by {
	int l,b;
	pass_by(int a, int b){
		l= a;
		this.b =b;
	}
	pass_by(pass_by obj, pass_by obj1){
		
	}
	void volume(){
		System.out.println(l*b);
	}
	public static void main(String[] args) {
		pass_by obj = new pass_by(5,10);
		pass_by obj1 = new pass_by(12,34);
		pass_by obj2 = new pass_by(obj, obj1);

	}

}
