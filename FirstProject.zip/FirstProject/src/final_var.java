
public class final_var {
	public static void main(String[] args) {
		final String name = "samson";
		System.out.println(name);
//		name = "wilson";
//		System.out.println(name);

	}

}
