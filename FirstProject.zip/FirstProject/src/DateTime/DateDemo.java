package DateTime;

import java.util.Date;
import java.time.LocalDate;

public class DateDemo {

	public static void main(String[] args) {
		
		Date d = new Date();
		System.out.println(d);
		
		LocalDate today = LocalDate.now();
		System.out.println(today);
		
		LocalDate t = LocalDate.of(2023, 03, 01);
		System.out.println(t);
		
		// Add days, months, years
        LocalDate futureDate = today.plusDays(10);
        System.out.println("Future Date (10 days later): " + futureDate);

        // Subtract days
        LocalDate pastDate = today.minusWeeks(2);
        System.out.println("Past Date (2 weeks ago): " + pastDate);
/*
        // Get day of the week and day of the year
        System.out.println("Day of the week: " + today.getDayOfWeek());
        System.out.println("Day of the year: " + today.getDayOfYear());

        // Check if a year is a leap year
        System.out.println("Is this a leap year? " + today.isLeapYear());
  */
		
	}

}
