
public class cuboid_method_over {
	int l,b;
	void volume() {
		System.out.println(l*b);
	}

	public static void main(String[] args) {
		 

	}

}
