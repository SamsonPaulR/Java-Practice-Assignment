
public class gc_demo {
		void meth()
		{
			System.out.println("i ma in method");
		}
		public void finalize()
		{
			System.out.println("deleting object");
		}
			public static void main(String[] args) {
			gc_demo obj=new gc_demo();
			obj.meth();
			obj=null;
			System.gc();
			

			}

		}
