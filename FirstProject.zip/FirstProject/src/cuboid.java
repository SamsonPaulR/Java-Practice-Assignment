import java.util.Scanner;

public class cuboid {
	int length, breadth, height;
	
	void setValue(int a, int b, int c) {
		length = a;
		breadth = b;
		height = c;
	}
	
	void display() {
		int res = length * breadth * height;
		System.out.println(res);
	}

	public static void main(String[] args) {
		
		Scanner s = new Scanner(System.in);
		System.out.print("Enter lenght: ");
		int a = s.nextInt();
		System.out.print("Enter Breadth: ");
		int b = s.nextInt();
		System.out.print("Enter Height");
		int c = s.nextInt();
		
		cuboid cu = new cuboid();
		
		cu.setValue(a, b, c);
		cu.display();

	}

}
