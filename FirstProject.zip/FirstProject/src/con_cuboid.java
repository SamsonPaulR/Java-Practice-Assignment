import java.util.Scanner;

class cubo{
	int l,b,h;


	cubo(int l, int b, int h){
		this.l = l;
		this.b = b;
		this.h = h;
	}
	public cubo(int l, int b) {
		this.l = l;
		this.b = b;
	}
	
	void display() {
		int result = l*b*h;
		System.out.println("cuboid area is: "+result);
	}
}

public class con_cuboid {

	public static void main(String[] args) {
		cubo obj = new cubo(2,3,5);
		obj.display();
		cubo obj1 = new cubo(2,3);
		obj1.display();
	}

}
