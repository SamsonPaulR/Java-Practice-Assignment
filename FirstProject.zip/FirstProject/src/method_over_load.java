public class method_over_load {
    int l, b, h;

    // Overloaded method with three parameters
    void setDimensions(int l, int b, int h) {
        this.l = l;
        this.b = b;
        this.h = h;
    }

    // Overloaded method with two parameters
    void setDimensions(float l, int b) {
        this.l = (int) l; // Explicit conversion from float to int
        this.b = b;
        this.h = 1; // Default value for h
    }

    void display() {
        int result = l * b * h;
        System.out.println("Cuboid area is: " + result);
    }

    public static void main(String[] args) {
        method_over_load obj = new method_over_load();
        obj.setDimensions(2, 3, 5); // Using the three-parameter method
        obj.display();

        method_over_load obj1 = new method_over_load();
        obj1.setDimensions(2.1f, 3); // Using the two-parameter method
        obj1.display();
    }
}
