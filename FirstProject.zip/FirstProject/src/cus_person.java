import java.util.Scanner;

class person{
	int id;
	String name;
	double salary;
	
	//constructor
	person(int id, String name, double salary){
		this.id = id;
        this.name = name;
        this.salary = salary;
	}
	
	//constructor overloading
	public person(int id, String name) {
		this.id = id;
		this.name = name;
	}
	
	void display() {
		System.out.println("Id:" +id);
		System.out.println("Name:" +name);
		System.out.println("Salary:" +salary);
	}
}
	
public class cus_person {
	public static void main(String[] args) {
		person a = new person(1,"samson",234567);
		a.display();
		person b = new person(2,"paul");
		b.display();
	}

}
