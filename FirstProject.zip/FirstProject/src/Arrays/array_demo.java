package Arrays;
import java.util.Scanner;

public class array_demo {

	public static void main(String[] args) {
		int arr[] = new int[5];
		Scanner scan = new Scanner(System.in);
		for(int i=0;i<arr.length;i++)
		{
			System.out.println("enter elemnt for position"+(i+1));
			arr[i]=scan.nextInt();
		}
		System.out.println("displaying array elements");
		for(int i=0; i<arr.length; i++) {
			System.out.println(arr[i]);
		}
		
		//enhance for loop
		for (int g : arr) {
			System.out.println(g);
		}

	}

}
