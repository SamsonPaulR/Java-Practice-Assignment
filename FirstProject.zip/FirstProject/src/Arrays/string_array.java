package Arrays;

public class string_array {

	public static void main(String[] args) {
		String arr[] = {"samson","wilson","richard"};
		
		String arr1[] = new String[3];
		arr1[0] = "samson";
		arr1[1] = "samson";
		arr1[2] = "samson";
		
		for(String family : arr) {
			System.out.println(family);
		}
		
		for(String name : arr1) {
			System.out.println(name);
		}
}
}