package Arrays;
import java.util.Scanner;

public class find_existing {
	
	public void find() {
		
	}
	

	public static void main(String[] args) {
		int num[] = {1,2,3,4,5};
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter no to find:");
		int a = scan.nextInt();
		
		

	}

}
