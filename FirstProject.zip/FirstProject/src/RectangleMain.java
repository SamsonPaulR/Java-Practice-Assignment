import java.util.Scanner;

class Rectangle{
	int length, breadth;
	void setValue(int i, int j) {
		length = i;
		breadth = j;
	}
	void show_area() {
		int area = length * breadth;
		System.out.println("Area of Rectangle is:" +area);
	}
}
public class RectangleMain {

	public static void main(String[] args) {
		Rectangle rec1 = new Rectangle();
		Scanner s = new Scanner(System.in);
		System.out.print("Enter Leangth:");
		int a = s.nextInt();
		System.out.print("Enter Breadth:");
		int b = s.nextInt();
//		rec1.length = 3;
//		rec1.breadth = 4;
		rec1.setValue(a,b);
		rec1.show_area();
		
	}

}
