package march8;
import java.util.Scanner;

public class bank {

	public static void main(String[] args) {
		Scanner val = new Scanner(System.in);
		System.out.print("Enter Name:");
		String name = val.nextLine();
		System.out.print("Enter Id:");
		int id = val.nextInt();
		System.out.print("Enter Salary:");
		float salary = val.nextFloat();
		customer person1 = new customer(id,name,salary);
		person1.display();

	}

}
