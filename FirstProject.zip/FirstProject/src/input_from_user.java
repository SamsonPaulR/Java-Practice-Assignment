import java.util.Scanner;

public class input_from_user {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Number:");
		int a = s.nextInt();
		System.out.println("Enter Double:");
		double b = s.nextDouble();
		
	}

}
