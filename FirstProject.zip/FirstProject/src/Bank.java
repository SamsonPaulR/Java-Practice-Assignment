/*   Task:
Create a BankAccount class with the following attributes and methods:

A static variable interestRate that represents the interest rate for all accounts.
Instance variables: accountNumber, accountHolder, and balance.
A constructor to initialize an account.
A method deposit(double amount) to add money to the balance.
A method withdraw(double amount) to deduct money from the balance (ensure the balance does not go negative).
A static method setInterestRate(double rate) to update the interest rate for all accounts.
A method displayAccountDetails() to print the account details along with the current interest rate.
  Create a BankDemo class with the main method:

Instantiate two bank accounts.
Deposit and withdraw some money.
Change the interest rate using the static method.
Display the details of both accounts.
Question:
Implement the BankAccount class and BankDemo class. Demonstrate the effect of using a static variable and static method in Java.


Expected output:
Account Number: 101, Holder: Alice, Balance: 5000.0, Interest Rate: 5.0%
Account Number: 102, Holder: Bob, Balance: 3000.0, Interest Rate: 5.0%

Updating Interest Rate to 6.0%

Account Number: 101, Holder: Alice, Balance: 5000.0, Interest Rate: 6.0%
Account Number: 102, Holder: Bob, Balance: 3000.0, Interest Rate: 6.0%
*/

// BankAccount class
class BankAccount {
    private int accountNumber;
    private String accountHolder;
    private double balance;

    // Static variable for interest rate
    private static double interestRate;

    // Constructor to initialize the account
    public BankAccount(int accountNumber, String accountHolder, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolder = accountHolder;
        this.balance = balance;
    }

    // Method to deposit money
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println(amount + " deposited. New balance: " + balance);
        } else {
            System.out.println("Deposit amount must be positive.");
        }
    }

    // Method to withdraw money
    public void withdraw(double amount) {
        if (amount > 0 && balance >= amount) {
            balance -= amount;
            System.out.println(amount + " withdrawn. New balance: " + balance);
        } else if (amount > balance) {
            System.out.println("Insufficient balance.");
        } else {
            System.out.println("Withdrawal amount must be positive.");
        }
    }

    // Static method to set the interest rate
    public static void setInterestRate(double rate) {
        if (rate > 0) {
            interestRate = rate;
            System.out.println("Interest rate updated to: " + rate + "%");
        } else {
            System.out.println("Interest rate must be positive.");
        }
    }

    // Method to display account details
    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber + ", Holder: " + accountHolder
                + ", Balance: " + balance + ", Interest Rate: " + interestRate + "%");
    }
}

// BankDemo class
public class Bank {
    public static void main(String[] args) {
        // Instantiate two bank accounts
        BankAccount account1 = new BankAccount(101, "Alice", 5000.0);
        BankAccount account2 = new BankAccount(102, "Bob", 3000.0);

        // Set the initial interest rate
        BankAccount.setInterestRate(5.0);

        // Display the details of both accounts
        account1.displayAccountDetails();
        account2.displayAccountDetails();

        System.out.println("\nUpdating Interest Rate to 6.0%\n");

        // Update the interest rate using the static method
        BankAccount.setInterestRate(6.0);

        // Display the details of both accounts again
        account1.displayAccountDetails();
        account2.displayAccountDetails();
    }
}

