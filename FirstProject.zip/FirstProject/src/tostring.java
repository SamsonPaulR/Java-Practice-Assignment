// Example of overriding toString() method
class Person {
    private String name;
    private int age;

    // Constructor
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    // Getter and Setter methods (Optional, but good practice)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    // Overriding the toString() method
    @Override
    public String toString() {
        return "Person{name='" + name + "', age=" + age + "}";
    }
}

public class tostring {
    public static void main(String[] args) {
        // Create a Person object
        Person person = new Person("Alice", 30);

        // Call toString() method
        System.out.println(person.toString()); // Explicit call
        System.out.println(person); // Implicit call
    }
}
