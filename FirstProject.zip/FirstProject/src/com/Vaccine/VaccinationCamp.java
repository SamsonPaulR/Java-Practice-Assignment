package com.Vaccine;

import java.util.ArrayList;

//Vaccine class definition
class Vaccine {
private int age;
private float dosage;

// Constructor
public Vaccine(int age) {
   this.age = age;
}

// Getter for age
public int getAge() {
   return age;
}

// Setter for dosage
public void setDosage(float dosage) {
   this.dosage = dosage;
}

// Getter for dosage
public float getDosage() {
   return dosage;
}
}

// VaccinationCamp class definition
public class VaccinationCamp {
    ArrayList<Vaccine> list = new ArrayList<>();

    // Method to add a Vaccine object to the list
    public void addVaccine(Vaccine vaccine) {
        list.add(vaccine);
    }

    // Method to assign vaccine dosages based on age
    public void assignVaccine() {
        for (Vaccine v : list) {
            if (v.getAge() >= 45) {
                v.setDosage(250);
            } else if (v.getAge() >= 20) {
                v.setDosage(200);
            } else {
                v.setDosage(100);
            }
        }
    }

    // Method to calculate total dosage injected
    public float vaccineInjected() {
        float totalDosage = 0;
        for (Vaccine v : list) {
            totalDosage += v.getDosage();
        }
        return totalDosage;
    }

    // Main method to test the program
    public static void main(String[] args) {
        VaccinationCamp camp = new VaccinationCamp();

        // Adding Vaccine objects with different ages
        camp.addVaccine(new Vaccine(50)); // Age 50
        camp.addVaccine(new Vaccine(30)); // Age 30
        camp.addVaccine(new Vaccine(15)); // Age 15

        // Assigning dosages
        camp.assignVaccine();

        // Printing total dosage injected
        System.out.println("Total Dosage Injected: " + camp.vaccineInjected());
    }
}
