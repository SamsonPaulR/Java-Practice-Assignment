package com.interface1;

interface cal {
    int x = 5, y = 4; // Variables in an interface are public, static, and final by default.
    void add();
    void sub();
}

interface culate extends cal {
    void mul();
    void div();
}

public class example1 implements culate {
    // Implement all methods from the interfaces
    @Override
    public void add() {
        System.out.println("Addition: " + (x + y));
    }

    @Override
    public void sub() {
        System.out.println("Subtraction: " + (x - y));
    }

    @Override
    public void mul() {
        System.out.println("Multiplication: " + (x * y));
    }

    @Override
    public void div() {
        System.out.println("Division: " + (x / y));
    }

    public static void main(String[] args) {
        culate obj = new example1(); // Create an object of the implementing class
        obj.add();
        obj.sub();
        obj.mul();
        obj.div();
    }
}
