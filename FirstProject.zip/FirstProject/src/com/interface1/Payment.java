package com.interface1;

// Define the Payment interface
interface Payment1 {
    void processPayment(double amount);
    String getPaymentMethod();
}

// Implement CreditCardPayment class
class CreditCardPayment implements Payment1 {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing credit card payment of $" + amount);
    }

    @Override
    public String getPaymentMethod() {
        return "Credit Card";
    }
}

// Implement PayPalPayment class
class PayPalPayment implements Payment1 {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing PayPal payment of $" + amount);
    }

    @Override
    public String getPaymentMethod() {
        return "PayPal";
    }
}

// Implement BankTransferPayment class
class BankTransferPayment implements Payment1 {
    @Override
    public void processPayment(double amount) {
        System.out.println("Processing bank transfer payment of $" + amount);
    }

    @Override
    public String getPaymentMethod() {
        return "Bank Transfer";
    }
}

// PaymentDemo class to demonstrate polymorphism
public class Payment {
    public static void processPayment(Payment1 payment, double amount) {
        System.out.println("Using payment method: " + payment.getPaymentMethod());
        payment.processPayment(amount);
    }

    public static void main(String[] args) {
        // Create instances of different payment methods
        Payment1 creditCardPayment = new CreditCardPayment();
        Payment1 payPalPayment = new PayPalPayment();
        Payment1 bankTransferPayment = new BankTransferPayment();

        // Demonstrate polymorphism
        processPayment(creditCardPayment, 100.50);
        processPayment(payPalPayment, 200.75);
        processPayment(bankTransferPayment, 300.00);
    }
}
