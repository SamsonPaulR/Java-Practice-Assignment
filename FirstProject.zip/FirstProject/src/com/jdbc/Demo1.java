package com.jdbc;

import com.DbConnection.DBConnection;
import java.sql.*;
import java.util.Scanner;

public class Demo1 {

    public static void main(String[] args) {
        // Establish the connection using the DBConnection class
        Connection con = DBConnection.getConnection();

        if (con == null) {
            System.err.println("Connection error");
            return;
        }

        Scanner scan = new Scanner(System.in);

        try {
            // Insert operation
            System.out.println("Enter ID to store:");
            int id = scan.nextInt();
            scan.nextLine(); // Consume the newline character after the integer input

            System.out.println("Enter name:");
            String name = scan.nextLine();

            String sqlInsert = "INSERT INTO emp1 (id, name) VALUES (?, ?)";
            PreparedStatement psInsert = con.prepareStatement(sqlInsert);
            psInsert.setInt(1, id);
            psInsert.setString(2, name);

            int rowsInserted = psInsert.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("1 row inserted successfully.");
            }

            // Fetch operation
            System.out.print("Enter E_ID to find: ");
            int searchId = scan.nextInt();

            String sqlFetch = "SELECT * FROM HR.EMP WHERE e_id = ?";
            PreparedStatement psFetch = con.prepareStatement(sqlFetch);
            psFetch.setInt(1, searchId);

            ResultSet rs = psFetch.executeQuery();
            while (rs.next()) {
                int fetchedId = rs.getInt(1);
                String fetchedName = rs.getString(2);
                System.out.println("ID: " + fetchedId + ", Name: " + fetchedName);
            }

        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            try {
                if (con != null && !con.isClosed()) {
                    con.close();
                }
            } catch (SQLException e) {
                System.out.println("Error closing connection: " + e.getMessage());
            }
        }
    }
}
