package com.collections;

import java.util.*;

public class ArrayListDemo {

	public static void main(String[] args) {
		List l = new ArrayList();
		
		l.add(3);
		l.add(4.1f);
		l.add("Samson");
		//add at specific place
		l.add(1, "wilson");
		
		System.out.println(l);
		System.out.println(l.contains("Samson"));
		System.out.println(l.contains("samson"));
		System.out.println(l.isEmpty());
		//find size of an arraylist
		System.out.println(l.size());
		//get specified element in an arraylist using index Number
		System.out.println(l.get(0));
		//updating arraylist elements using index
		l.set(0, "Richard");
		System.out.println(l);
		//removing arraylist element
		l.remove(2);
		System.out.println(l);
		
		
		for (Object s:l)
		{
			System.out.println(s);
		}
		
		System.out.println("--------------------");
		
		Iterator w = l.iterator();
		while(w.hasNext()) {
			Object o = w.next(); 
			System.out.println(o);
		}
		
	}

}
