package com.collections;

import java.util.*;

public class SetDemo {

    public static void main(String[] args) {

        // Using TreeSet
        Set<String> s = new TreeSet<>();
        s.add("ben");
        s.add("ken");
        s.add("zen");
        // TreeSet doesn't support duplicate values
        s.add("ken");

        // Using HashSet
        Set<Object> h = new HashSet<>();
        h.add("ben");
        h.add("ken");
        h.add("zen");
        h.add(3); // Adding integer is fine with HashSet as it's heterogeneous
        h.add("ken");

        // Using LinkedHashSet
        Set d = new LinkedHashSet<>();
        d.add("ben");
        d.add("ken");
        d.add("zen");
        d.add(3);
        d.add("ken");

        // Remove an element
        System.out.println(d.remove("ken")); // Outputs true if "ken" is removed

        // Check if an element exists
        System.out.println(d.contains("ken")); // Outputs false if "ken" was removed earlier

        // Iterating over the set
        for (Object x : d) { // Corrected variable name from 'b' to 'd'
            System.out.println(x);
        }

        // Printing sets
        System.out.println(s); // Outputs elements in sorted order (TreeSet)
        System.out.println(h); // Outputs elements in no particular order (HashSet)
        System.out.println(d); // Outputs elements in insertion order (LinkedHashSet)
    }
}
