package com.collections;

import java.util.*;

public class InsurancePolicyManager {

    private TreeMap<Integer, String> policyMap = new TreeMap<>();

    // Method to add policy details
    public void addPolicyDetails(int policyId, String policyName) {
        policyMap.put(policyId, policyName);
    }

    // Method to search based on policy type
    public List<Integer> searchBasedOnPolicyType(String policyType) {
        List<Integer> matchingPolicyIds = new ArrayList<>();
        for (Map.Entry<Integer, String> entry : policyMap.entrySet()) {
            if (entry.getValue().toLowerCase().contains(policyType.toLowerCase())) {
                matchingPolicyIds.add(entry.getKey());
            }
        }
        return matchingPolicyIds;
    }

    // Method to display all policies
    public void displayAllPolicies() {
        System.out.println("Policies in sorted order (by Policy ID):");
        for (Map.Entry<Integer, String> entry : policyMap.entrySet()) {
            System.out.println("Policy ID: " + entry.getKey() + ", Policy Name: " + entry.getValue());
        }
    }

    // Main method
    public static void main(String[] args) {
        InsurancePolicyManager manager = new InsurancePolicyManager();
        Scanner scanner = new Scanner(System.in);

        // Adding policies
        System.out.println("Enter the number of policies:");
        int n = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        for (int i = 0; i < n; i++) {
            System.out.println("Enter Policy ID:");
            int policyId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline
            System.out.println("Enter Policy Name:");
            String policyName = scanner.nextLine();

            manager.addPolicyDetails(policyId, policyName);
        }

        // Display all policies
        manager.displayAllPolicies();

        // Search for policies based on type
        System.out.println("Enter the policy type to search for:");
        String policyType = scanner.nextLine();

        List<Integer> matchingPolicies = manager.searchBasedOnPolicyType(policyType);
        System.out.println("Matching Policy IDs:");
        for (int id : matchingPolicies) {
            System.out.println(id);
        }

        scanner.close();
    }
}
