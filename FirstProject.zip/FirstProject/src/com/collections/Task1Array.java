package com.collections;


import java.util.*;

public class Task1Array {

	public static void main(String[] args) {
		
		ArrayList list = new ArrayList();
		
		list.add("Java");
		list.add(100);
		list.add(3.14f);
		list.add("Spring");
		list.add(true);
		
		System.out.println("List elements and their types:");
        for (Object element : list) {
            System.out.println(element + " (Type: " + element.getClass().getSimpleName() + ")");
        }
        
        list.remove(2);

        // Print the list after removal
        System.out.println("\nList after removing the third element:");
        for (Object element : list) {
            System.out.println(element);
        }
		

	}

}
