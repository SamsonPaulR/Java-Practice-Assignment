package com.collections;

import java.util.*;

public class HashMapExample {

    public static void main(String[] args) {

        // Use generic types for HashMap
        HashMap<Integer, String> m = new HashMap<>();
        Map<String, Integer> s = new HashMap<>();

        // Populating the first HashMap
        m.put(1, "Samson");
        m.put(2, "Richard");
        m.put(3, "Wilson");
        m.put(null, "Name"); // Overwrites existing null key
        m.put(4, null);
        m.put(null, null); // Overwrites null key again

        // Populating the second HashMap
        s.put("samson", 1);
        s.put(null, null); // Adds a null key
        s.put("hello", 2);

        // Print the HashMaps
        System.out.println(m);
        System.out.println(s);

        // Accessing elements
        System.out.println(m.get(1)); // Corrected the key type to Integer
        System.out.println(s.containsKey("hello"));

        // Loop through HashMap m with appropriate types
        for (Map.Entry<Integer, String> p : m.entrySet()) {
            System.out.println(p.getKey() + ":" + p.getValue());
        }
        
        Collection<String> name = s.keySet();
        
        for (String n:name) {
        	System.out.println(n);
        }
    }
}
