package com.DbConnection;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

    public static Connection getConnection() {
        Connection con = null;
        try {
            // Load the PostgreSQL driver
//            Class.forName("org.postgresql.Driver");
        	
        	//load the Oracle driver
        	Class.forName("oracle.jdbc.driver.OracleDriver");

            // Establish the connection for postgres
            //con = DriverManager.getConnection("jdbc:postgresql://localhost/sundaram", "postgres", "samson2002");

            // Establish the connection for oracle
            con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "samson2002");
            
            System.out.println("Connection established successfully.");
        } catch (Exception e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
        return con;
    }
}
