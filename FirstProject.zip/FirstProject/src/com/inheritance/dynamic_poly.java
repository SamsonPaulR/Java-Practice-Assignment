package com.inheritance;

class Shape
{
	void area()
	{
		System.out.println("printing shape area");
	}
}
class Rect1 extends Shape
{
	void area()
	{
		System.out.println("printing Rectangle area");
	}
	void meth()
	{
		System.out.println("hello all");
	}
}
class Square extends Shape
{
	void area()
	{
		System.out.println("printing Square area");
	}
}
public class dynamic_poly {
	public static void main(String args[])
	{
		
	
		Shape s=new Shape();
		s.area();
		s=new Rect1();
		s.area();

		s=new Square();
		s.area();
}
}