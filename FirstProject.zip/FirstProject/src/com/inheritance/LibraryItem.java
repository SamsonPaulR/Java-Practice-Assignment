package com.inheritance;



//------------------------------------------------------------------
//The base class LibraryItem contains common attributes and behaviors.
//The subclasses Book and Magazine inherit from LibraryItem and extend functionality.
//Encapsulation & Method Overriding
//
//displayDetails() method is overridden in both Book and Magazine classes to display specific attributes like genre (for books) and issueNumber (for magazines).
//User-Friendly Interface
//
//Simple console-based implementation to display information about library items.
//        LibraryItem
//        ├── title : String
//        ├── author : String
//        ├── yearPublished : int
//        ├── displayDetails()
//              │
//              ├── Book
//              │   ├── genre : String
//              │   ├── displayDetails()
//              │
//              ├── Magazine
//                  ├── issueNumber : int
//                  ├── displayDetails()
                  
                  
                  

//Base class for library items
class Library {
 private String title, author;
 private int year;

 // Constructor for the Library class
 Library(String title, String author, int year) {
     this.title = title;
     this.author = author;
     this.year = year;
 }

 // Getters and setters
 public String getTitle() {
     return title;
 }

 public void setTitle(String title) {
     this.title = title;
 }

 public String getAuthor() {
     return author;
 }

 public void setAuthor(String author) {
     this.author = author;
 }

 public int getYear() {
     return year;
 }

 public void setYear(int year) {
     this.year = year;
 }

 // Method to display details (intended for overriding)
 public void displayDetails() {
     System.out.println("Title: " + this.title + ", Author: " + this.author + ", Year: " + this.year);
 }
}

//Subclass Book that extends Library
class Book extends Library {
 private String genre;

 // Constructor for Book class
 Book(String title, String author, int year, String genre) {
     super(title, author, year);
     this.genre = genre;
 }

 // Getter and setter for genre
 public String getGenre() {
     return genre;
 }

 public void setGenre(String genre) {
     this.genre = genre;
 }

 // Overriding the displayDetails method
 @Override
 public void displayDetails() {
     super.displayDetails(); // Display common attributes from Library
     System.out.println("Genre: " + this.genre);
 }
}

//Subclass Magazine that extends Library
class Magazine extends Library {
 private int issueNumber;

 // Constructor for Magazine class
 Magazine(String title, String author, int year, int issueNumber) {
     super(title, author, year);
     this.issueNumber = issueNumber;
 }

 // Getter and setter for issueNumber
 public int getIssueNumber() {
     return issueNumber;
 }

 public void setIssueNumber(int issueNumber) {
     this.issueNumber = issueNumber;
 }

 // Overriding the displayDetails method
 @Override
 public void displayDetails() {
     super.displayDetails(); // Display common attributes from Library
     System.out.println("Issue Number: " + this.issueNumber);
 }
}

//Main class to test the functionality
public class LibraryItem {
 public static void main(String[] args) {
     // Dynamic Polymorphism: Using the base class reference to call overridden methods
     Library item;

     // Creating a Book object and assigning it to a Library reference
     item = new Book("1984", "George Orwell", 1949, "Dystopian");
     item.displayDetails(); // Calls the overridden method in Book

     System.out.println();

     // Creating a Magazine object and assigning it to a Library reference
     item = new Magazine("National Geographic", "Various Authors", 2023, 101);
     item.displayDetails(); // Calls the overridden method in Magazine
 }
}

