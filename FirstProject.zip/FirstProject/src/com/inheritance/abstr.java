package com.inheritance;


abstract class shape1{
	int length;
	int breadth;
	abstract void area();
	
	shape1(int a, int b){
		length = a ;
		breadth = b;
	}
	
	public void display() {
		System.out.println("area");
	}
}

class cuboid extends shape1{
	int h;
	cuboid(int a, int b, int c) {
		super(a, b);
		h = c;
	}

	void area() {
		System.out.println(length*breadth*h);
	}
}


public class abstr {

	public static void main(String[] args) {
		shape1 s = new cuboid(1,3,5);
		s.area();

	}

}
