package com.string;

import java.util.*;

public class StudentSorting {
	
	

	public static void main(String[] args) {
		
		

	}

}
