package com.string;

public class refEquality_Demo {

	public static void main(String[] args) {
		String s = "samson";
		String w = "wilson";
		//Reference equality
		if(s==w) {
			System.out.println("True");
		}
		else {
			System.out.println("false");
		}
		
		//object equality
		if(s.equals(w)) {
			System.out.println("True");
		}
		else {
			System.out.println("false");
		}
	}

}
