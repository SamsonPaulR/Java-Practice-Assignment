package com.string;

public class srtring_demo {

	public static void main(String[] args) {
		String s = "samson";
		String w = "wilson";
		s.toUpperCase();//garbage collection
		System.out.println(s);//its return orginal value
		System.out.println(s.toLowerCase());
		System.out.println(s.toUpperCase());
		System.out.println(s.charAt(0));
		System.out.println(s.startsWith("a"));
		System.out.println(s.replace("s", "w"));
		System.out.println(s.concat("wilson"));
		System.out.println(s.contains("s"));
		System.out.println(s.indexOf("m"));
		
		if(s.equals(w)) {
			System.out.println("Yes");
			
		}
		else {
			System.out.println("No");
		}
		
		StringBuffer d = new  StringBuffer("hello");
		d.append("samson");
		System.out.println(d);
		
		StringBuilder e = new StringBuilder("hello");
		d.append("wilson");
		System.out.println(e);
	}

}
