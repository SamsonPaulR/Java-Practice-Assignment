package com.Java8;

import java.util.*;

public class OptionalDemo2 {

	public static void main(String[] args) {
		
		// Create an empty Optional
        Optional<String> emptyOptional = Optional.empty();
        
        // Check if the Optional is empty
        if (emptyOptional.isEmpty()) {
            System.out.println("The Optional is empty!");
        } else {
            System.out.println("The Optional contains a value.");
        }

	}

}
