package com.Java8;

import java.util.*;

interface I2{
	int meth(int a, int b);
}



public class LambdaExpression {

	public static void main(String[] args) {
		
		I2 obj = (m, n) -> {
		m++;
		n++;
		return(m+n);
		};
		
		System.out.println(obj.meth(23, 56));
	}

}
