package com.Java8;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamDemo {

	public static void main(String[] args) {
		
		List<Integer> l = Arrays.asList(4,5,6,77,8);
		/*
		//convert list into stream
		Stream<Integer> s = l.stream();
		
		//lambda
		s.forEach(x -> System.out.println(x));
		
		//method reference
		s.forEach(System.out :: println); */
		
		
		l.stream().forEach(x->System.out.println(x));
		
		l.stream().forEach(System.out :: println);
		
		List<Integer> l2 = l.stream().filter(x->x>4).collect(Collectors.toList());
		
		int s=l.stream().filter(x->x>4).mapToInt(x->x).sum();
		System.out.println("sum is"+s);
		
		OptionalInt e = l.stream()
                .filter(x -> x % 2 == 0)
                .mapToInt(x -> x)
                .findFirst();
                //.findAny();
		System.out.println("Even:"+e);
		
		OptionalInt f = l.stream()
				.distinct()
				.mapToInt(x->x)
				.findAny();
		
		if(f.isPresent()) {
			System.out.println(f.getAsInt());
		}
		
		
		List<String> l1 = Arrays.asList("Sam","son","paul","Richard","Wilson");
		
		l1.stream().map(x->x.toUpperCase()).filter(x->x.contains("a")).forEach(System.out::println);	
		
		long count = l.stream().filter(x -> x % 2 == 0).count();
		System.out.println(count);
		
		System.out.println("-------------------");
		
		l1.stream().sorted().forEach(System.out::println);
		
		System.out.println("-------------------");
		
		l1.stream().sorted(Comparator.naturalOrder()).forEach(System.out::println);
		
		System.out.println("-------------------");

		l1.stream().sorted(Comparator.reverseOrder()).forEach(System.out::println);
		
		System.out.println("-------------------");
		//reduce
		
		int sum = l.stream()
				.reduce(0, (a,b) -> a+b);
		System.out.println(sum);
		
		System.out.println("-------------------");
		
		String[] course = {"Java", "Python", "c#"};
		
		Stream<String> c1 = Arrays.stream(course);
		
		Stream<String> c2 = Stream.of("SQL","oracle","mongodb");
		
		//System.out.println(c1.allMatch(x->x.contains("P"))); 
		
		System.out.println(c1.anyMatch(x->x.contains("P"))); 
		
		//System.out.println(c1.noneMatch(x->x.contains("P")));
		
		System.out.println("-------------------");
		
		//List<String> b = c1.map(x->x.toUpperCase()).collect(Collectors.toList());
		//System.out.println(b);
		
		Optional<Integer> o = l.stream().findAny();
		
		if(o.isPresent()) {
			System.out.println(o.get());
		}
				
		 // Find the maximum value in the list using Stream
        Optional<Integer> maxValue = l.stream().max(Comparator.comparingInt(x -> x));

        // Print the maximum value safely
        maxValue.ifPresent(System.out::println);
		
	}

}
