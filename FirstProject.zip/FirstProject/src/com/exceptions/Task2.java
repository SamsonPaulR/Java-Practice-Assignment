package com.exceptions;

import java.util.Scanner;

public class Task2 {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        System.out.print("Enter any String: ");
        String str = scan.nextLine();

        try {
            validstr(str); // Call the method to validate the string
            System.out.println("Valid");
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (RuntimeException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            scan.close(); // Close the scanner
            System.out.println("Program Ended");
        }
    }

    // Method to validate the string
    public static void validstr(String str) throws IllegalArgumentException, RuntimeException {
        if (str.isEmpty()) {
            throw new IllegalArgumentException("Input not correct");
        } else if (str.length() < 5) { 
        	throw new RuntimeException("Input must be at least 5 letters"); 
        }
    }
}
