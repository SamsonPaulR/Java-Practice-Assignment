package com.exceptions;

// Define the custom checked exception
class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// Define the custom unchecked exception
class InvalidAmountException extends RuntimeException {
    public InvalidAmountException(String message) {
        super(message);
    }
}

// BankAccount class
class BankAccount {
    private double balance;

    // Constructor to initialize account balance
    public BankAccount(double balance) {
        this.balance = balance;
    }

    // Method to perform a withdrawal
    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount <= 0) {
            throw new InvalidAmountException("Withdrawal amount cannot be negative or zero.");
        }
        if (amount > balance) {
            throw new InsufficientFundsException("Insufficient funds. Available balance: " + balance);
        }
        balance -= amount;
        System.out.println("Withdrawal successful. Remaining balance: " + balance);
    }

    // Method to get current balance
    public double getBalance() {
        return balance;
    }
}

// Main class to test the program
public class BankingApplication {
    public static void main(String[] args) {
        // Create a BankAccount with an initial balance
        BankAccount account = new BankAccount(500.0);

        // Test scenarios
        try {
            // Test: Withdraw a negative amount
            account.withdraw(-100.0);
        } catch (InvalidAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            // Test: Withdraw an amount greater than the balance
            account.withdraw(600.0);
        } catch (InvalidAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Exception: " + e.getMessage());
        }

        try {
            // Test: Perform a successful withdrawal
            account.withdraw(300.0);
        } catch (InvalidAmountException e) {
            System.out.println("Exception: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("Exception: " + e.getMessage());
        }
    }
}
