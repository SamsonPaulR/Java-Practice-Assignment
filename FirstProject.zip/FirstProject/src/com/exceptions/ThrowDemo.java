package com.exceptions;

public class ThrowDemo {
	
	static void meth() {
		System.out.println("welcome to meth");
		throw new ArithmeticException("demo");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		meth();
		System.out.println("hello");
	}

}
