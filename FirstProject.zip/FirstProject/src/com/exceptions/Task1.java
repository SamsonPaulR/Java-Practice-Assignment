package com.exceptions;

import java.util.Scanner;

public class Task1 {

	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter an integer: ");
        int number = scanner.nextInt();
        
        try {
            // Validate the number
            validateNumber(number);
            System.out.println("Valid number entered: " + number);
        } catch (IllegalArgumentException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.out.println("Exception caught: " + e.getMessage());
        } finally {
            scanner.close();
            System.out.println("Program ended.");
        }
    }

    // Method to validate the number
    public static void validateNumber(int number) throws IllegalArgumentException, ArithmeticException {
        if (number < 0) {
            throw new IllegalArgumentException("Negative number not allowed!");
        } else if (number == 0) {
            throw new ArithmeticException("Zero is not a valid input!");
        }
        // If the number is positive, it is valid
	}

}
