package com.exceptions;

import java.io.*;

public class CheckedExceptionDemo {

	public static void main(String[] args) throws Exception {
		
		FileInputStream fis = new FileInputStream ("d:/desktop/JAM.txt");

	}

}
