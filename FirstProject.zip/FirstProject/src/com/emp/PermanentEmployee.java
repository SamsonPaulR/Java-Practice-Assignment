package com.emp;

public class PermanentEmployee extends Employee {
	double basic_pay;

	public PermanentEmployee(int id, String name, double basic_pay) {
		super(id, name);
		this.basic_pay = basic_pay;
	}
	
	public double getBasic_pay() {
		return basic_pay;
	}

	public void setBasic_pay(double basic_pay) {
		this.basic_pay = basic_pay;
	}
	
	public void calculateSalary() {
        this.salary = basic_pay - (0.12 * basic_pay);
    }

}

