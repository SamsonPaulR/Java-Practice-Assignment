package com.emp;

public class TemporaryEmployee extends Employee {
	int hoursWorked;
	int hourlyWages;
	public TemporaryEmployee(int id, String name, int hoursWorked, int hourlyWages) {
		super(id, name);
		this.hoursWorked = hoursWorked;
		this.hourlyWages = hourlyWages;
	}
	
	public int getHoursWorked() {
		return hoursWorked;
	}

	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}

	public int getHourlyWages() {
		return hourlyWages;
	}

	public void setHourlyWages(int hourlyWages) {
		this.hourlyWages = hourlyWages;
	}

	 public void calculateSalary() {
	        this.salary = hoursWorked * hourlyWages;
	    }
}
