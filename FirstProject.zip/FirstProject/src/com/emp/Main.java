package com.emp;
import java.util.Scanner;

class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        loan loan = new loan();

        System.out.println("Enter Employee Type (1 for Permanent, 2 for Temporary): ");
        int employeeType = scanner.nextInt();

        if (employeeType == 1) {
            System.out.println("Enter Employee ID, Name, and Basic Pay: ");
            int id = scanner.nextInt();
            String name = scanner.next();
            double basicPay = scanner.nextDouble();

            PermanentEmployee permEmp = new PermanentEmployee(id, name, basicPay);
            permEmp.calculateSalary();
            System.out.println("Permanent Employee Details:");
            System.out.println("ID: " + permEmp.getEmp_id());
            System.out.println("Name: " + permEmp.getEmp_name());
            System.out.println("Salary: " + permEmp.getSalary());
            System.out.println("Loan Amount: " + loan.calculateLoanAmount(permEmp));
        } 
        else if (employeeType == 2) {
            System.out.println("Enter Employee ID, Name, Hours Worked, and Hourly Wages: ");
            int id = scanner.nextInt();
            String name = scanner.next();
            int hoursWorked = scanner.nextInt();
            int hourlyWages = scanner.nextInt();

            TemporaryEmployee tempEmp = new TemporaryEmployee(id, name, hoursWorked, hourlyWages);
            tempEmp.calculateSalary();
            System.out.println("Temporary Employee Details:");
            System.out.println("ID: " + tempEmp.getEmp_id());
            System.out.println("Name: " + tempEmp.getEmp_name());
            System.out.println("Salary: " + tempEmp.getSalary());
            System.out.println("Loan Amount: " + loan.calculateLoanAmount(tempEmp));
        } 
        else {
            System.out.println("Invalid Employee Type.");
        }

        scanner.close();
    }
}
