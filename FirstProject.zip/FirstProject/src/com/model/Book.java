package com.model;

public class Book {
	private int book_id;
	private String author;
	private String category;
	private float price;
	
	public Book(int )
	
}
