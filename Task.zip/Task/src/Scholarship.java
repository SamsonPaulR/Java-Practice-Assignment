

import java.util.*;

class Student {
    private String name;
    private String college;
    private float percentage;
    private float scholarship;

    // Constructor
    Student(String name, String college, float percentage) {
        this.name = name;
        this.college = college;
        this.percentage = percentage;
        this.scholarship = 0; // Default scholarship is 0
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public float getPercentage() {
        return percentage;
    }

    public void setPercentage(float percentage) {
        this.percentage = percentage;
    }

    public float getScholarship() {
        return scholarship;
    }

    public void setScholarship(float scholarship) {
        this.scholarship = scholarship;
    }
}

class Portal {
    // ArrayList to store Student objects
    ArrayList<Student> studentList = new ArrayList<>();

    // Method to assign scholarships
    public void assignScholarship() {
        for (Student student : studentList) {
            if (student.getPercentage() >= 91) {
                student.setScholarship(10000);
            } else if (student.getPercentage() >= 81) {
                student.setScholarship(5000);
            } else {
                student.setScholarship(0);
            }
        }
    }

    // Method to calculate the total scholarship amount
    public float totalScholarship() {
        float total = 0;
        for (Student student : studentList) {
            total += student.getScholarship();
        }
        return total;
    }

    // Method to find the college with the maximum scholarship
    public String totalMaxScholarshipOfCollege() {
        HashMap<String, Float> collegeScholarshipMap = new HashMap<>();

        // Calculate total scholarship per college
        for (Student student : studentList) {
            String collegeName = student.getCollege();
            float scholarship = student.getScholarship();

            collegeScholarshipMap.put(collegeName, collegeScholarshipMap.getOrDefault(collegeName, 0f) + scholarship);
        }

        // Find the college with the maximum scholarship
        String maxScholarshipCollege = null;
        float maxScholarship = 0;

        for (String college : collegeScholarshipMap.keySet()) {
            float totalScholarship = collegeScholarshipMap.get(college);
            if (totalScholarship > maxScholarship) {
                maxScholarship = totalScholarship;
                maxScholarshipCollege = college;
            }
        }

        return maxScholarshipCollege;
    }
}

public class Scholarship {
    public static void main(String[] args) {
        // Create Portal object
        Portal obj = new Portal();

        // Add students to the Portal
        obj.studentList.add(new Student("Steve", "IIT", 89));
        obj.studentList.add(new Student("Bob", "NIT", 94));
        obj.studentList.add(new Student("Alice", "Abcd", 59));

        // Assign scholarships
        obj.assignScholarship();

        // Print total scholarship amount
        System.out.println(obj.totalScholarship()); 

        // Print college with maximum scholarship
        System.out.println(obj.totalMaxScholarshipOfCollege()); 
    }
}
