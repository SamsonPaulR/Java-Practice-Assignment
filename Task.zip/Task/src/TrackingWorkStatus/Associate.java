package TrackingWorkStatus;

import java.util.Scanner;

//Class to track associate's work status
class Associate {
 private int associateId;
 private String associateName;
 private String workStatus;

 // Constructor
 public Associate(int associateId, String associateName) {
     this.associateId = associateId;
     this.associateName = associateName;
 }

 // Getter and Setter for associateId
 public int getAssociateId() {
     return associateId;
 }

 public void setAssociateId(int associateId) {
     this.associateId = associateId;
 }

 // Getter and Setter for associateName
 public String getAssociateName() {
     return associateName;
 }

 public void setAssociateName(String associateName) {
     this.associateName = associateName;
 }

 // Getter and Setter for workStatus
 public String getWorkStatus() {
     return workStatus;
 }

 public void setWorkStatus(String workStatus) {
     this.workStatus = workStatus;
 }

 // Method to track associate's status based on training days
 public void trackAssociateStatus(int days) {
     if (days < 0) {
         this.workStatus = "Invalid number of days"; // Handle negative input
     } else if (days >= 0 && days <= 20) {
         this.workStatus = "Core skills";
     } else if (days >= 21 && days <= 40) {
         this.workStatus = "Advanced modules";
     } else if (days >= 41 && days <= 60) {
         this.workStatus = "Project phase";
     } else {
         this.workStatus = "Deployed in project";
     }
 }

//Main class to interact with the program

 public static void main(String[] args) {
     Scanner scanner = new Scanner(System.in);

     try {
         // Input for associate details
         System.out.print("Enter Associate ID: ");
         int associateId = scanner.nextInt();

         System.out.print("Enter Associate Name: ");
         scanner.nextLine(); // Consume newline
         String associateName = scanner.nextLine();

         System.out.print("Enter Number of Training Days: ");
         int days = scanner.nextInt();

         // Validate input
         if (days < 0) {
             System.out.println("Error: Number of training days cannot be negative.");
             return;
         }

         // Create Associate object
         Associate associate = new Associate(associateId, associateName);

         // Track work status
         associate.trackAssociateStatus(days);

         // Display details
         System.out.println("\nAssociate Details:");
         System.out.println("Name: " + associate.getAssociateName());
         System.out.println("Work Status: " + associate.getWorkStatus());
     } catch (Exception e) {
         System.out.println("Invalid input! Please enter valid details.");
     } finally {
         scanner.close(); // Close the scanner
     }
 }
}
