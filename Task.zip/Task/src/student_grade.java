

import java.util.Scanner;

public class student_grade {
    private int stud_id;
    private String stud_name;
    private int[] marks;
    private float avg;
    private char grade;

    // Getter and Setter methods
    public int getStudId() {
        return stud_id;
    }

    public void setStudId(int id) {
        this.stud_id = id;
    }

    public String getName() {
        return stud_name;
    }

    public void setName(String name) {
        this.stud_name = name;
    }

    public int[] getMarks() {
        return marks;
    }

    public void setMarks(int[] marks) {
        this.marks = marks;
    }

    public float getAvg() {
        return avg;
    }

    public char getGrade() {
        return grade;
    }

    // Method to calculate average marks
    public void calculateAverage() {
        int sum = 0;
        for (int mark : marks) {
            sum += mark;
        }
        this.avg = (float) sum / marks.length;
    }

    // Method to assign grade based on conditions
    public void findGrade() {
        for (int mark : marks) {
            if (mark < 50) {
                this.grade = 'F';
                return; // Exit as soon as failing grade is detected
            }
        }
        if (avg >= 80 && avg <= 100) {
            this.grade = 'O';
        } else {
            this.grade = 'A';
        }
    }

    // Main method
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create a StudentGrade object
        student_grade student = new student_grade();

        // Input student details
        System.out.print("Enter Student ID: ");
        student.setStudId(scanner.nextInt());
        scanner.nextLine(); // Consume the newline character

        System.out.print("Enter Student Name: ");
        student.setName(scanner.nextLine());

        int numberOfSubjects;
        do {
            System.out.print("Enter the number of subjects: ");
            numberOfSubjects = scanner.nextInt();
            if (numberOfSubjects <= 0) {
                System.out.println("Number of subjects must be a positive integer. Please try again.");
            }
        } while (numberOfSubjects <= 0);

        int[] marks = new int[numberOfSubjects];
        for (int i = 0; i < numberOfSubjects; i++) {
            do {
                System.out.print("Enter marks for subject " + (i + 1) + ": ");
                marks[i] = scanner.nextInt();
                if (marks[i] < 0) {
                    System.out.println("Marks must be a positive value. Please try again.");
                }
            } while (marks[i] < 0);
        }
        student.setMarks(marks);

        // Calculate average and grade
        student.calculateAverage();
        student.findGrade();

        // Display student details
        System.out.println("\nStudent Details:");
        System.out.println("ID: " + student.getStudId());
        System.out.println("Name: " + student.getName());
        System.out.printf("Average Marks: %.2f%n", student.getAvg());
        System.out.println("Grade: " + student.getGrade());

        scanner.close();
    }
}
