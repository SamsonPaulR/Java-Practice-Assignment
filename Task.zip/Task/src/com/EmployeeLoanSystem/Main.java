package com.EmployeeLoanSystem;

import java.util.*;

public class Main {

	public static void main(String[] args) {
		 Scanner scanner = new Scanner(System.in);

	        System.out.println("Enter Employee Type (Permanent/Temporary): ");
	        String employeeType = scanner.nextLine();

	        Employee employee;
	        if (employeeType.equalsIgnoreCase("Permanent")) {
	            System.out.println("Enter Employee ID: ");
	            int id = scanner.nextInt();
	            System.out.println("Enter Employee Name: ");
	            scanner.nextLine(); // Consume newline
	            String name = scanner.nextLine();
	            System.out.println("Enter Basic Pay: ");
	            double basicPay = scanner.nextDouble();

	            employee = new PermanentEmployee(id, name, basicPay);
	        } else if (employeeType.equalsIgnoreCase("Temporary")) {
	            System.out.println("Enter Employee ID: ");
	            int id = scanner.nextInt();
	            System.out.println("Enter Employee Name: ");
	            scanner.nextLine(); // Consume newline
	            String name = scanner.nextLine();
	            System.out.println("Enter Hours Worked: ");
	            int hoursWorked = scanner.nextInt();
	            System.out.println("Enter Hourly Wages: ");
	            int hourlyWages = scanner.nextInt();

	            employee = new TemporaryEmployee(id, name, hoursWorked, hourlyWages);
	        } else {
	            System.out.println("Invalid Employee Type");
	            scanner.close();
	            return;
	        }

	        // Calculate salary
	        employee.calculateSalary();

	        // Display employee details and loan amount
	        System.out.println("Employee ID: " + employee.getEmployeeId());
	        System.out.println("Employee Name: " + employee.getEmployeeName());
	        System.out.println("Employee Salary: " + employee.getSalary());

	        Loan loan = new Loan();
	        System.out.println("Loan Amount: " + loan.calculateLoanAmount(employee));

	        scanner.close();
	}

}
