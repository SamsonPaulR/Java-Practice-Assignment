

import java.util.Scanner;

public class HighestMarkPerSem {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of semesters: ");
        int semesters = scanner.nextInt();

        if (semesters <= 0) {
            System.out.println("Invalid number of semesters.");
            return;
        }

        for (int i = 1; i <= semesters; i++) {
            System.out.println("Enter the number of subjects for semester " + i + ": ");
            int subjects = scanner.nextInt();

            if (subjects <= 0) {
                System.out.println("Invalid number of subjects.");
                return;
            }

            int highestMark = -1;

            for (int j = 1; j <= subjects; j++) {
                System.out.println("Enter the mark for subject " + j + " (0-100): ");
                int mark = scanner.nextInt();

                if (mark < 0 || mark > 100) {
                    System.out.println("Invalid mark entered. Program will terminate.");
                    return;
                }

                if (mark > highestMark) {
                    highestMark = mark;
                }
            }

            System.out.println("The highest mark in semester " + i + " is: " + highestMark);
        }

        scanner.close();
    }
}

